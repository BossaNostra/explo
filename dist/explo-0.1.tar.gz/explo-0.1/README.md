# Team 3

This package was created as part of a group project @Explore Data Science Academy 2020

## Build this package locally

`python setup.py sdist`

## Install this package from Github

`pip install git+http://github.com/BossaNostra.explo.git`

## Updating this package from GitHub

`pip install --upgrade git+https://github.com/BossaNostra/explo.git`

